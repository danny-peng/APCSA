public class Furniture {
    String name;

    public Furniture(String name) {
        this.name = name; 
    }
}
