public class Main {
    public static void main(String[] args) {
        Lamp lamp = new Lamp("Yellow");

        lamp.turnOn(50);
    }
}
