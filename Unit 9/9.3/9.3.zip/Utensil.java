public class Utensil {
    private String material;

    public Utensil(String material) {
        this.material = material;
    }

    public void use() {
        System.out.println("Utensil used!");
    }
}
