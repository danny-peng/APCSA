public class Car extends Vehicle {
    public String toString() {
        return "Car";
    }
}
