public class VehicleOperator {
    public void operate(Vehicle vehicle) {
        System.out.println("Operated " + vehicle);
    }
}
