public class Vehicle {
    public String toString() {
        return "Vehicle";
    }
}
