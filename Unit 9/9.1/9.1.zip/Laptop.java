public class Laptop extends Computer {
    public Laptop() {}
    
    public Laptop(double price) {
        super(price);
    }
}