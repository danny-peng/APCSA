public class Computer {
    private double price;
    
    public Computer() {};
    
    public Computer(double price) {
        this.price = price;
    }

    public double getPrice() {
        return price;
    }
}