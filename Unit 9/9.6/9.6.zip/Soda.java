public class Soda extends Drink{
    public boolean flat;

    public Soda() {}

    public Soda(boolean flat) {
        this.flat = flat;
    }

    public String toString() {
        if (flat) return "A flat soda";
        return "A soda";
    }

    public boolean equals(Soda other) {
        return other.flat == this.flat;
    }
}
