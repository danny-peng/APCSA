public class Main {
    public static void main(String[] args) {
        Drink water = new Drink(true);
        Drink cola = new Soda();

        System.out.println("Water: " + water);
        System.out.println("Cola: " + cola);
        System.out.println();

        System.out.println(water.equals(cola));
    }
}