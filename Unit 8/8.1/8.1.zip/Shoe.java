public class Shoe {
    private int size;
    public Shoe(int size) {
        this.size = size;
    }
    public String toString() {
        return "Shoe of size " + size;
    }
    public int getSize() {return size;}
}
